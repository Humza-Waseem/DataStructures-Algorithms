import csv

def save_contacts_to_csv(users):
    with open("phone_directory.csv", "w", newline='') as csvfile:
        fieldnames = ['Username', 'Name', 'Number']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()

        for username, contacts in users.items():
            for contact in contacts:
                writer.writerow({'Username': username, 'Name': contact['name'], 'Number': contact['number']})


def load_contacts_from_csv():
    users = {}
    
    with open("phone_directory.csv", "r") as csvfile:
        reader = csv.DictReader(csvfile)
        
        for row in reader:
            username = row['Username']
            if username not in users:
                users[username] = []
            
            users[username].append({'name': row['Name'], 'number': row['Number']})

    return users

    



# # users = {
# #     'Hamza': [{'name': 'Haider', 'number': '1234567890'}, {'name': 'Kami', 'number': '9876543210'}],
# #     'Saad': [{'name': 'NOmi', 'number': '1112223333'}, {'name': 'Salman', 'number': '4445556666'}],
# # }

# # Save contacts to CSV file
# # save_contacts_to_csv(users)

# # Load contacts from CSV file

# add_contact()
# save_contacts_to_csv(users)
# loaded_users = load_contacts_from_csv()


# # Display loaded contacts
# for username, contacts in loaded_users.items():
#     print(f"User: {username}")
#     for contact in contacts:
#         print(f"  {contact['name']}: {contact['number']}")



